<?php
/*
* Plugin Name: IPBan Login Tracker
* Description: Tracks both failed and successful login attempts and writes them to a custom log file for IPBan to process.
* Version: 1.0
* Author: IPBan Pro (Jeff Johnson)
* Author URI: https://ipban.com
* Plugin URI: https://ipban.com/wordpress-plugin
* Text Domain: login-tracker
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

try {
	// Determine the log file path based on the operating system
	if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
		// Windows environment
		define('IPBAN_LOG_FILE', 'C:/IPBanCustomLogs/login_attempts_wp.log');
	} else {
		// Linux environment
		//define('IPBAN_LOG_FILE', WP_CONTENT_DIR . '/logs/ipban_login_attempts_wp.log');
		define('IPBAN_LOG_FILE', '/var/log/ipbancustom_login_attempts_wp.log');

		// Create the log file if it doesn't exist
		if (!file_exists(IPBAN_LOG_FILE)) {
			wp_mkdir_p(dirname(IPBAN_LOG_FILE));
			file_put_contents(IPBAN_LOG_FILE, '');
			chmod(IPBAN_LOG_FILE, 0664); // -rw-rw-r--
			chown(IPBAN_LOG_FILE, 'www-data');
			chgrp(IPBAN_LOG_FILE, 'www-data');
		}

		// sudo touch /var/log/ipbancustom_login_attempts_wp.log
		// sudo chmod 0664 /var/log/ipbancustom_login_attempts_wp.log
		// sudo chown www-data:www-data /var/log/ipbancustom_login_attempts_wp.log
	}

	// Register the activation hook to log initialization only once
	register_activation_hook(__FILE__, function() {
		// create directory if needed
		if (!file_exists(dirname(IPBAN_LOG_FILE))) {
			wp_mkdir_p(dirname(IPBAN_LOG_FILE));
		}
		file_put_contents(IPBAN_LOG_FILE, gmdate('Y-m-d H:i:s') . " - IPBan WordPress Logging Initialized!\n", FILE_APPEND | LOCK_EX);
	});

	// Register the authenticate filter for tracking logins
	add_filter('authenticate', 'ipban_track_login', 1000, 3);
} catch (Exception $e) {
}

// Function to get the real IP address of the user, accounting for proxies like Cloudflare
function get_user_ip_address() {
    // Check for Cloudflare's IP header
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $ip_address = $_SERVER['HTTP_CF_CONNECTING_IP'];
    }
    // Check for X-Forwarded-For header, which may contain a list of IPs (client, proxies)
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip_list = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip_address = trim($ip_list[0]); // The first IP in the list is the client's IP
    }
    // Fall back to REMOTE_ADDR
    else {
        $ip_address = $_SERVER['REMOTE_ADDR'];
    }

    return $ip_address;
}

function ipban_track_login($user, $username, $password) {
    // Get the IP address of the user trying to log in
    $ip_address = get_user_ip_address();

    // Get the current timestamp
    $timestamp = gmdate('Y-m-d\TH:i:s\Z');

    // Define the source as WordPress
    $source = 'WordPress';

    $log_entry = '';

    if ($user instanceof WP_User) {
        $log_entry = "{$timestamp}, ipban success login, ip address: {$ip_address}, source: {$source}, user: {$username}\n";
    } else {
        $log_entry = "{$timestamp}, ipban failed login: {$ip_address}, source: {$source}, user: {$username}\n";        
    }

    // Write the log entry to the log file
    file_put_contents(IPBAN_LOG_FILE, $log_entry, FILE_APPEND | LOCK_EX);

    return $user; // Make sure to return the $user object for the authentication process to continue
}

?>